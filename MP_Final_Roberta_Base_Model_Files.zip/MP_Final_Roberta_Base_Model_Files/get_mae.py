# -*- coding: utf-8 -*-
"""
Created on Thu Apr 22 15:22:53 2021

@author: dell
"""

import pandas as pd
import numpy as np


pred_path = input("Enter Prediction file Path : ")
true_path = input("Enter True Value file file Path : ")
feature = input("Enter Feature name : ")

test_pred = pd.read_csv(pred_path)
test_true = pd.read_csv(true_path)




if feature == 'nFix':
    mae_nfix = np.mean(np.absolute(test_pred['nfix'] - test_true['nFix']))
    print('Mean Absolute Error of nFix is: %.2f' % mae_nfix)
    
elif feature == 'FFD':
    mae_ffd = np.mean(np.absolute(test_pred['ffd'] - test_true['FFD']))
    print('Mean Absolute Error of FFD is: %.2f' % mae_ffd)
    
elif feature == 'GPT':
    mae_gpt = np.mean(np.absolute(test_pred['gpt'] - test_true['GPT']))
    print('Mean Absolute Error of GPT is: %.2f' % mae_gpt)
    
elif feature == 'TRT':
    mae_trt = np.mean(np.absolute(test_pred['trt'] - test_true['TRT']))
    print('Mean Absolute Error of TRT is: %.2f' % mae_trt)
    
elif feature == 'fixProp':
    mae_fprop = np.mean(np.absolute(test_pred['fprop'] - test_true['fixProp']))
    print('Mean Absolute Error of fixProp is: %.3f' % mae_fprop)
