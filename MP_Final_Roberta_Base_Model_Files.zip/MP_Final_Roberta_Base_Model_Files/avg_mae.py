# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 08:59:44 2021

@author: dell
"""

import pandas as pd
import numpy as np

nFix_path = input("Enter nFix Predictions path : ")
FFD_path = input("Enter FFD Predictions path : ")
GPT_path = input("Enter GPT Predictions path : ")
TRT_path = input("Enter TRT Predictions path : ")
fixProp_path = input("Enter fixProp Predictions path : ")
true_path = input("Enter True Value file Path : ")

nFix_pred = pd.read_csv(nFix_path)
FFD_pred = pd.read_csv(FFD_path)
GPT_pred = pd.read_csv(GPT_path)
TRT_pred = pd.read_csv(TRT_path)
fixProp_pred = pd.read_csv(fixProp_path)
true_pred = pd.read_csv(true_path)


mae_nfix = np.mean(np.absolute(nFix_pred['nfix'] - true_pred['nFix']))
mae_ffd = np.mean(np.absolute(FFD_pred['ffd'] - true_pred['FFD']))
mae_gpt = np.mean(np.absolute(GPT_pred['gpt'] - true_pred['GPT']))
mae_trt = np.mean(np.absolute(TRT_pred['trt'] - true_pred['TRT']))
mae_fprop = np.mean(np.absolute(fixProp_pred['fprop'] - true_pred['fixProp']))

print('')
print(' Mean Absolute Error of nFix is: %.4f' % mae_nfix)
print(' Mean Absolute Error of FFD is: %.4f' % mae_ffd)
print(' Mean Absolute Error of GPT is: %.4f' % mae_gpt)
print(' Mean Absolute Error of TRT is: %.4f' % mae_trt)
print(' Mean Absolute Error of fixProp is: %.4f' % mae_fprop)
print(' -----------------------------------------------------------------------')
print(" Average MAE of all features : %.5f" % np.mean([mae_nfix,mae_ffd,mae_gpt,mae_trt,mae_fprop]))
